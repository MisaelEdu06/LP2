﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Globalization;
using System.Linq;
using System.Runtime.ExceptionServices;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Pcalc
{
    public partial class Form1 : Form
    {
        Double Numero1, Numero2, Resultado; // globais

        private void txtNum1_Validated(object sender, EventArgs e)
        {
            if (!double.TryParse(txtNum1.Text, out Numero1))
            {
                MessageBox.Show("Numero 1 inválido!");
                txtnum2.Focus();
            }
        }

        private void btnmais_Click(object sender, EventArgs e)
        {
            Resultado = Numero1 + Numero2;
            txtresult.Text = Resultado.ToString();
        }

        private void btnmenos_Click(object sender, EventArgs e)
        {
            Resultado = Numero1 - Numero2;
            txtresult.Text = Resultado.ToString();

        }

        private void btnmult_Click(object sender, EventArgs e)
        {
            Resultado = Numero1 * Numero2;
            txtresult.Text = Resultado.ToString();
        }

        private void btndivisao_Click(object sender, EventArgs e)
        {
            if (Numero2 == 0)
            {
                MessageBox.Show("Não é possivel dividir por zero!");
            }
            else
            {
                Resultado = Numero1 / Numero2;
                txtresult.Text = Resultado.ToString();
            }
        }

        private void btnsair_Click(object sender, EventArgs e)
        {
          Close();
        }

        private void btnlimpar_Click(object sender, EventArgs e)
        {
            Numero1 = 0;
            Numero2 = 0;    
        }

        public Form1()
        {
            InitializeComponent();
        }

        private void txtnum2_Validated(object sender, EventArgs e)
        {
            if (!double.TryParse(txtnum2.Text, out Numero2))
            {
                MessageBox.Show("Numero 2 inválido!");
                txtnum2.Focus();
            }
        }
    }

       

       
 }

