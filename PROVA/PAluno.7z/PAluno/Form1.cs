﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.VisualBasic;

namespace PAluno
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnExecutar_Click(object sender, EventArgs e)
        {
            double [,] Notas = new double[10,10];
            //double [,] Notas = new double[10,5];
            double[] MediaAluno = new double[10];
            double MediaAlunos = 0;
 
            for (int i = 0; i < 10; i++)
            {
                string NAluno = Interaction.InputBox($"Digite o Numero do aluno {i + 1}:");
                if (!double.TryParse(NAluno, out Notas[0,i]))
                {
                    MessageBox.Show("Número Inválido!");
                    Close();
                }
              
                for (int j = 0; j < 3; j++)
                {
                    string Nota = Interaction.InputBox($"Digite a nota do professor {j + 1}:");
                    if (!double.TryParse(Nota, out Notas[i, j]))
                    {
                        MessageBox.Show("Número Inválido!");
                        Close();
                    }
                    MediaAlunos += Notas[1, j];
                    if( j == 2)
                    {
                        MediaAluno[i] = MediaAlunos / 3;
                    }

                    
                }

            }
     
            for (int i = 0; i < 11; i++)
            {
                ListBoxAlunos.Items.Add($"Aluno RA:{Notas[0,i]} Nota Professor 1:{Notas[i,0]} Nota Professor 2: {i, 1} Nota Professor 3: {i,2} Media {MediaAluno[i]}");
            }
        }


        private void btnLimpar_Click(object sender, EventArgs e)
        {
           ListBoxAlunos.Items.Clear();
        }
    }
}
