﻿namespace Pclasses
{
    partial class FrmHorista
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.bttInstancHorist = new System.Windows.Forms.Button();
            this.txtDataEntrEmpr = new System.Windows.Forms.TextBox();
            this.txtSalHora = new System.Windows.Forms.TextBox();
            this.txtNome = new System.Windows.Forms.TextBox();
            this.txtMatricula = new System.Windows.Forms.TextBox();
            this.lblEntradaEmp = new System.Windows.Forms.Label();
            this.lblSalarioHora = new System.Windows.Forms.Label();
            this.lblNome1 = new System.Windows.Forms.Label();
            this.lblMatricula1 = new System.Windows.Forms.Label();
            this.lblFaltas = new System.Windows.Forms.Label();
            this.txtFaltas = new System.Windows.Forms.TextBox();
            this.lblHrsTrab = new System.Windows.Forms.Label();
            this.txtHrsTrab = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // bttInstancHorist
            // 
            this.bttInstancHorist.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bttInstancHorist.Location = new System.Drawing.Point(266, 296);
            this.bttInstancHorist.Name = "bttInstancHorist";
            this.bttInstancHorist.Size = new System.Drawing.Size(168, 78);
            this.bttInstancHorist.TabIndex = 18;
            this.bttInstancHorist.Text = "Instanciar Horista";
            this.bttInstancHorist.UseVisualStyleBackColor = true;
            this.bttInstancHorist.Click += new System.EventHandler(this.bttInstancHorist_Click);
            // 
            // txtDataEntrEmpr
            // 
            this.txtDataEntrEmpr.Location = new System.Drawing.Point(208, 236);
            this.txtDataEntrEmpr.Name = "txtDataEntrEmpr";
            this.txtDataEntrEmpr.Size = new System.Drawing.Size(97, 20);
            this.txtDataEntrEmpr.TabIndex = 17;
            // 
            // txtSalHora
            // 
            this.txtSalHora.Location = new System.Drawing.Point(208, 122);
            this.txtSalHora.Name = "txtSalHora";
            this.txtSalHora.Size = new System.Drawing.Size(106, 20);
            this.txtSalHora.TabIndex = 16;
            // 
            // txtNome
            // 
            this.txtNome.Location = new System.Drawing.Point(208, 77);
            this.txtNome.Name = "txtNome";
            this.txtNome.Size = new System.Drawing.Size(262, 20);
            this.txtNome.TabIndex = 15;
            // 
            // txtMatricula
            // 
            this.txtMatricula.Location = new System.Drawing.Point(208, 37);
            this.txtMatricula.Name = "txtMatricula";
            this.txtMatricula.Size = new System.Drawing.Size(87, 20);
            this.txtMatricula.TabIndex = 14;
            // 
            // lblEntradaEmp
            // 
            this.lblEntradaEmp.AutoSize = true;
            this.lblEntradaEmp.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblEntradaEmp.Location = new System.Drawing.Point(14, 238);
            this.lblEntradaEmp.Name = "lblEntradaEmp";
            this.lblEntradaEmp.Size = new System.Drawing.Size(143, 18);
            this.lblEntradaEmp.TabIndex = 13;
            this.lblEntradaEmp.Text = "Entrada na Empresa";
            // 
            // lblSalarioHora
            // 
            this.lblSalarioHora.AutoSize = true;
            this.lblSalarioHora.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblSalarioHora.Location = new System.Drawing.Point(31, 122);
            this.lblSalarioHora.Name = "lblSalarioHora";
            this.lblSalarioHora.Size = new System.Drawing.Size(117, 18);
            this.lblSalarioHora.TabIndex = 12;
            this.lblSalarioHora.Text = "Salário por Hora";
            // 
            // lblNome1
            // 
            this.lblNome1.AutoSize = true;
            this.lblNome1.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblNome1.Location = new System.Drawing.Point(99, 79);
            this.lblNome1.Name = "lblNome1";
            this.lblNome1.Size = new System.Drawing.Size(49, 18);
            this.lblNome1.TabIndex = 11;
            this.lblNome1.Text = "Nome";
            // 
            // lblMatricula1
            // 
            this.lblMatricula1.AutoSize = true;
            this.lblMatricula1.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblMatricula1.Location = new System.Drawing.Point(80, 39);
            this.lblMatricula1.Name = "lblMatricula1";
            this.lblMatricula1.Size = new System.Drawing.Size(68, 18);
            this.lblMatricula1.TabIndex = 10;
            this.lblMatricula1.Text = "Matricula";
            // 
            // lblFaltas
            // 
            this.lblFaltas.AutoSize = true;
            this.lblFaltas.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblFaltas.Location = new System.Drawing.Point(99, 201);
            this.lblFaltas.Name = "lblFaltas";
            this.lblFaltas.Size = new System.Drawing.Size(48, 18);
            this.lblFaltas.TabIndex = 20;
            this.lblFaltas.Text = "Faltas";
            // 
            // txtFaltas
            // 
            this.txtFaltas.Location = new System.Drawing.Point(208, 199);
            this.txtFaltas.Name = "txtFaltas";
            this.txtFaltas.Size = new System.Drawing.Size(62, 20);
            this.txtFaltas.TabIndex = 21;
            // 
            // lblHrsTrab
            // 
            this.lblHrsTrab.AutoSize = true;
            this.lblHrsTrab.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblHrsTrab.Location = new System.Drawing.Point(14, 166);
            this.lblHrsTrab.Name = "lblHrsTrab";
            this.lblHrsTrab.Size = new System.Drawing.Size(134, 18);
            this.lblHrsTrab.TabIndex = 22;
            this.lblHrsTrab.Text = "Horas Trabalhadas";
            // 
            // txtHrsTrab
            // 
            this.txtHrsTrab.Location = new System.Drawing.Point(208, 164);
            this.txtHrsTrab.Name = "txtHrsTrab";
            this.txtHrsTrab.Size = new System.Drawing.Size(62, 20);
            this.txtHrsTrab.TabIndex = 23;
            // 
            // FrmHorista
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(731, 415);
            this.Controls.Add(this.txtHrsTrab);
            this.Controls.Add(this.lblHrsTrab);
            this.Controls.Add(this.txtFaltas);
            this.Controls.Add(this.lblFaltas);
            this.Controls.Add(this.bttInstancHorist);
            this.Controls.Add(this.txtDataEntrEmpr);
            this.Controls.Add(this.txtSalHora);
            this.Controls.Add(this.txtNome);
            this.Controls.Add(this.txtMatricula);
            this.Controls.Add(this.lblEntradaEmp);
            this.Controls.Add(this.lblSalarioHora);
            this.Controls.Add(this.lblNome1);
            this.Controls.Add(this.lblMatricula1);
            this.Name = "FrmHorista";
            this.Text = "FrmHorista";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Button bttInstancHorist;
        private System.Windows.Forms.TextBox txtDataEntrEmpr;
        private System.Windows.Forms.TextBox txtSalHora;
        private System.Windows.Forms.TextBox txtNome;
        private System.Windows.Forms.TextBox txtMatricula;
        private System.Windows.Forms.Label lblEntradaEmp;
        private System.Windows.Forms.Label lblSalarioHora;
        private System.Windows.Forms.Label lblNome1;
        private System.Windows.Forms.Label lblMatricula1;
        private System.Windows.Forms.Label lblFaltas;
        private System.Windows.Forms.TextBox txtFaltas;
        private System.Windows.Forms.Label lblHrsTrab;
        private System.Windows.Forms.TextBox txtHrsTrab;
    }
}