﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Pclasses
{
    abstract internal class Empregado
    {
        private int matricula; //atributo            da pra escrever codigo
        private string nomeEpregado;
        private DateTime dataEntradaEmpresa;


        public int Matricula //propriedade
        {
            get { return matricula; }
            set { matricula = value; }
        }

        public string NomeEpregado
        {
            get { return nomeEpregado; }
            set { nomeEpregado = value; }
        }

        public DateTime DataEntradaEmpresa
        {
            get { return dataEntradaEmpresa; }
            set { dataEntradaEmpresa = value; }
        }

        // método são ações/comportamentos
        // virtual -> pode ser sobreescrito

        public virtual int TempoTrabalho()
        {
            // representa o intervalo de tempo
            TimeSpan span =
            DateTime.Today.Subtract(DataEntradaEmpresa);
            return (span.Days);
        }

        //deve ser implementado
        // Derived class must implement this.

        public abstract double SalarioBruto();
        
        public Empregado()
        {
            System.Windows.Forms.MessageBox.Show("Aqui é empregado");
        }

        public Empregado(int matricula, string nomeEpregado, DateTime dataEntradaEmpresa)
        {
            Matricula = matricula;
            NomeEpregado = nomeEpregado;
            DataEntradaEmpresa = dataEntradaEmpresa;
            
        }
    }
}            
