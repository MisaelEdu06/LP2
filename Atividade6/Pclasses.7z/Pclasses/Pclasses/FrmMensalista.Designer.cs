﻿namespace Pclasses
{
    partial class FrmMensalista
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblMatricula1 = new System.Windows.Forms.Label();
            this.lblNome1 = new System.Windows.Forms.Label();
            this.lblSalarioMensal = new System.Windows.Forms.Label();
            this.lblEntradaEmp = new System.Windows.Forms.Label();
            this.txtMatricula1 = new System.Windows.Forms.TextBox();
            this.txtNome = new System.Windows.Forms.TextBox();
            this.txtSalMens = new System.Windows.Forms.TextBox();
            this.txtDataEntrEmpr = new System.Windows.Forms.TextBox();
            this.bttInstancMensa = new System.Windows.Forms.Button();
            this.bttInstancMensParame = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // lblMatricula1
            // 
            this.lblMatricula1.AutoSize = true;
            this.lblMatricula1.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblMatricula1.Location = new System.Drawing.Point(31, 32);
            this.lblMatricula1.Name = "lblMatricula1";
            this.lblMatricula1.Size = new System.Drawing.Size(68, 18);
            this.lblMatricula1.TabIndex = 0;
            this.lblMatricula1.Text = "Matricula";
            // 
            // lblNome1
            // 
            this.lblNome1.AutoSize = true;
            this.lblNome1.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblNome1.Location = new System.Drawing.Point(31, 78);
            this.lblNome1.Name = "lblNome1";
            this.lblNome1.Size = new System.Drawing.Size(49, 18);
            this.lblNome1.TabIndex = 1;
            this.lblNome1.Text = "Nome";
            // 
            // lblSalarioMensal
            // 
            this.lblSalarioMensal.AutoSize = true;
            this.lblSalarioMensal.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblSalarioMensal.Location = new System.Drawing.Point(31, 123);
            this.lblSalarioMensal.Name = "lblSalarioMensal";
            this.lblSalarioMensal.Size = new System.Drawing.Size(106, 18);
            this.lblSalarioMensal.TabIndex = 2;
            this.lblSalarioMensal.Text = "Salário Mensal";
            // 
            // lblEntradaEmp
            // 
            this.lblEntradaEmp.AutoSize = true;
            this.lblEntradaEmp.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblEntradaEmp.Location = new System.Drawing.Point(31, 168);
            this.lblEntradaEmp.Name = "lblEntradaEmp";
            this.lblEntradaEmp.Size = new System.Drawing.Size(198, 18);
            this.lblEntradaEmp.TabIndex = 3;
            this.lblEntradaEmp.Text = "Data de Entrada na Empresa";
            // 
            // txtMatricula1
            // 
            this.txtMatricula1.Location = new System.Drawing.Point(192, 32);
            this.txtMatricula1.Name = "txtMatricula1";
            this.txtMatricula1.Size = new System.Drawing.Size(87, 20);
            this.txtMatricula1.TabIndex = 4;
            // 
            // txtNome
            // 
            this.txtNome.Location = new System.Drawing.Point(192, 76);
            this.txtNome.Name = "txtNome";
            this.txtNome.Size = new System.Drawing.Size(262, 20);
            this.txtNome.TabIndex = 5;
            // 
            // txtSalMens
            // 
            this.txtSalMens.Location = new System.Drawing.Point(208, 124);
            this.txtSalMens.Name = "txtSalMens";
            this.txtSalMens.Size = new System.Drawing.Size(106, 20);
            this.txtSalMens.TabIndex = 6;
            // 
            // txtDataEntrEmpr
            // 
            this.txtDataEntrEmpr.Location = new System.Drawing.Point(248, 166);
            this.txtDataEntrEmpr.Name = "txtDataEntrEmpr";
            this.txtDataEntrEmpr.Size = new System.Drawing.Size(87, 20);
            this.txtDataEntrEmpr.TabIndex = 7;
            // 
            // bttInstancMensa
            // 
            this.bttInstancMensa.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bttInstancMensa.Location = new System.Drawing.Point(84, 222);
            this.bttInstancMensa.Name = "bttInstancMensa";
            this.bttInstancMensa.Size = new System.Drawing.Size(168, 78);
            this.bttInstancMensa.TabIndex = 8;
            this.bttInstancMensa.Text = "Instanciar Mensalista";
            this.bttInstancMensa.UseVisualStyleBackColor = true;
            this.bttInstancMensa.Click += new System.EventHandler(this.bttInstancMensa_Click);
            // 
            // bttInstancMensParame
            // 
            this.bttInstancMensParame.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bttInstancMensParame.Location = new System.Drawing.Point(302, 222);
            this.bttInstancMensParame.Name = "bttInstancMensParame";
            this.bttInstancMensParame.Size = new System.Drawing.Size(168, 78);
            this.bttInstancMensParame.TabIndex = 9;
            this.bttInstancMensParame.Text = "Instanciar Mensalista Passando Parametros";
            this.bttInstancMensParame.UseVisualStyleBackColor = true;
            this.bttInstancMensParame.Click += new System.EventHandler(this.bttInstancMensParame_Click);
            // 
            // FrmMensalista
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(610, 332);
            this.Controls.Add(this.bttInstancMensParame);
            this.Controls.Add(this.bttInstancMensa);
            this.Controls.Add(this.txtDataEntrEmpr);
            this.Controls.Add(this.txtSalMens);
            this.Controls.Add(this.txtNome);
            this.Controls.Add(this.txtMatricula1);
            this.Controls.Add(this.lblEntradaEmp);
            this.Controls.Add(this.lblSalarioMensal);
            this.Controls.Add(this.lblNome1);
            this.Controls.Add(this.lblMatricula1);
            this.Name = "FrmMensalista";
            this.Text = "FrmMensalista";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblMatricula1;
        private System.Windows.Forms.Label lblNome1;
        private System.Windows.Forms.Label lblSalarioMensal;
        private System.Windows.Forms.Label lblEntradaEmp;
        private System.Windows.Forms.TextBox txtMatricula1;
        private System.Windows.Forms.TextBox txtNome;
        private System.Windows.Forms.TextBox txtSalMens;
        private System.Windows.Forms.TextBox txtDataEntrEmpr;
        private System.Windows.Forms.Button bttInstancMensa;
        private System.Windows.Forms.Button bttInstancMensParame;
    }
}