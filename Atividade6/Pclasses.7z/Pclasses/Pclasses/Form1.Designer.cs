﻿namespace Pclasses
{
    partial class Form1
    {
        /// <summary>
        /// Variável de designer necessária.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpar os recursos que estão sendo usados.
        /// </summary>
        /// <param name="disposing">true se for necessário descartar os recursos gerenciados; caso contrário, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código gerado pelo Windows Form Designer

        /// <summary>
        /// Método necessário para suporte ao Designer - não modifique 
        /// o conteúdo deste método com o editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.bttMensalista = new System.Windows.Forms.Button();
            this.bttHorista = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // bttMensalista
            // 
            this.bttMensalista.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bttMensalista.Location = new System.Drawing.Point(119, 108);
            this.bttMensalista.Name = "bttMensalista";
            this.bttMensalista.Size = new System.Drawing.Size(140, 83);
            this.bttMensalista.TabIndex = 0;
            this.bttMensalista.Text = "Mensalista";
            this.bttMensalista.UseVisualStyleBackColor = true;
            this.bttMensalista.Click += new System.EventHandler(this.bttMensalista_Click);
            // 
            // bttHorista
            // 
            this.bttHorista.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bttHorista.Location = new System.Drawing.Point(379, 108);
            this.bttHorista.Name = "bttHorista";
            this.bttHorista.Size = new System.Drawing.Size(140, 83);
            this.bttHorista.TabIndex = 1;
            this.bttHorista.Text = "Horista";
            this.bttHorista.UseVisualStyleBackColor = true;
            this.bttHorista.Click += new System.EventHandler(this.bttHorista_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(687, 343);
            this.Controls.Add(this.bttHorista);
            this.Controls.Add(this.bttMensalista);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button bttMensalista;
        private System.Windows.Forms.Button bttHorista;
    }
}

