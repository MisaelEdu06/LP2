﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Pclasses
{
    public partial class FrmHorista : Form
    {
        public FrmHorista()
        {
            InitializeComponent();
        }

        private void bttInstancHorist_Click(object sender, EventArgs e)
        {
            Horista objHorista = new Horista();

            objHorista.NomeEpregado = txtNome.Text;
            objHorista.Matricula = Convert.ToInt32(txtMatricula.Text);
            objHorista.SalarioHora = Convert.ToDouble(txtSalHora.Text);
            objHorista.NumeroHora = Convert.ToDouble(txtHrsTrab.Text);
            objHorista.DataEntradaEmpresa = Convert.ToDateTime(txtDataEntrEmpr.Text);
            objHorista.DiasFalta = Convert.ToInt32(txtFaltas.Text);

            MessageBox.Show("Nome:" + objHorista.NomeEpregado +
                "\n" + "Matricula:" + objHorista.Matricula + "\n" +
                "Tempo Trabalho:" + objHorista.TempoTrabalho() +
                "\n" + "Salário:" + objHorista.SalarioBruto().ToString("N2"));
        }
    }
}
