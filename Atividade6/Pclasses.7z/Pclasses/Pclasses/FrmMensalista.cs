﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Pclasses
{
    public partial class FrmMensalista : Form
    {
        public FrmMensalista()
        {
            InitializeComponent();
        }

        private void bttInstancMensa_Click(object sender, EventArgs e)
        {
            Mensalista objMensalista = new Mensalista();

            objMensalista.NomeEpregado = txtNome.Text;
            objMensalista.Matricula = Convert.ToInt32(txtMatricula1.Text);
            objMensalista.DataEntradaEmpresa = Convert.ToDateTime(txtDataEntrEmpr.Text);
            objMensalista.SalarioMensal = Convert.ToDouble(txtSalMens.Text);


            MessageBox.Show("Nome=" + objMensalista.NomeEpregado + "\n" +
                    "Matrícula=" + objMensalista.Matricula + "\n" +
                    "Tempo de Trabalho=" + objMensalista.TempoTrabalho() + "\n" +
                    "Salário Final=" + objMensalista.SalarioBruto().ToString("N2"));


           //static
           MessageBox.Show(Mensalista.Empresa);
           MessageBox.Show(Mensalista.Filial);
        }

        private void bttInstancMensParame_Click(object sender, EventArgs e)
        {
            Mensalista objmensalista = new Mensalista(
                Convert.ToInt32(txtMatricula1.Text),
                txtNome.Text,
                Convert.ToDateTime(txtDataEntrEmpr.Text),
                Convert.ToDouble(txtSalMens.Text));

            MessageBox.Show("Nome=" + objmensalista.NomeEpregado + "\n" +
                    "Matrícula=" + objmensalista.Matricula + "\n" +
                    "Tempo de Trabalho=" + objmensalista.TempoTrabalho() + "\n" +
                    "Salário Final=" + objmensalista.SalarioBruto().ToString("N2"));

        }
    }
}
