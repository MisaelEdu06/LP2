﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics.Eventing.Reader;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Pimc
{
    public partial class Form1 : Form
    {
        public double Altura, Peso, Resultado;

        private void mskbxpeso_Validated(object sender, EventArgs e)
        {
            if (!double.TryParse(mskbxpeso.Text, out Peso))
            {
                MessageBox.Show("Número Inválido!");
                mskbxpeso.Focus();
            }
        }

        private void mskbxaltura_Validated(object sender, EventArgs e)
        {
            if (!double.TryParse(mskbxaltura.Text, out Altura))
            {
                MessageBox.Show("Número Inválido!");
                mskbxaltura.Focus();
            }
        }

        private void bttsair_Click(object sender, EventArgs e)
        {
            Close();    

        }

        private void bttlimpar_Click(object sender, EventArgs e)
        {
            mskbxaltura.Text = "";
            mskbxaltura.Text = "";
            txtclass.Text = "";
            txtresult.Text = "";

        }

        public Form1()
        {
            InitializeComponent();
        }

        private void bttcalcular_Click(object sender, EventArgs e)
        {
            if (Altura == 0 || Peso == 0)
            {
                MessageBox.Show("Valor deve ser maior que zeo!");
            }
            else
            {
                Resultado = Peso / Math.Pow(Altura, 2);
                Resultado = Math.Pow(Resultado, 1);
                txtresult.Text = Resultado.ToString();
            }
            if (Resultado < 18.5)
            {
                txtclass.Text = "MAGREZA";
            }
            else if (Resultado < 24.9)
            {
                txtclass.Text = "NORMAL";
            }
            else if (Resultado < 29.9)
            {
                txtclass.Text = "SOBRE PESO";
            }
            else if (Resultado < 39.9)
            {
                txtclass.Text = "OBESIDADE";
            }
            else if (Resultado > 40)
            {
                txtclass.Text = "OBESIDADE GRAVE";
            }

        }
    }
}
