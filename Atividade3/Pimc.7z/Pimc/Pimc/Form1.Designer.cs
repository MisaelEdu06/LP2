﻿namespace Pimc
{
    partial class Form1
    {
        /// <summary>
        /// Variável de designer necessária.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpar os recursos que estão sendo usados.
        /// </summary>
        /// <param name="disposing">true se for necessário descartar os recursos gerenciados; caso contrário, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código gerado pelo Windows Form Designer

        /// <summary>
        /// Método necessário para suporte ao Designer - não modifique 
        /// o conteúdo deste método com o editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblpeso = new System.Windows.Forms.Label();
            this.lblaltura = new System.Windows.Forms.Label();
            this.mskbxpeso = new System.Windows.Forms.MaskedTextBox();
            this.mskbxaltura = new System.Windows.Forms.MaskedTextBox();
            this.bttcalcular = new System.Windows.Forms.Button();
            this.txtresult = new System.Windows.Forms.TextBox();
            this.lblimc = new System.Windows.Forms.Label();
            this.lblclass = new System.Windows.Forms.Label();
            this.txtclass = new System.Windows.Forms.TextBox();
            this.bttlimpar = new System.Windows.Forms.Button();
            this.bttsair = new System.Windows.Forms.Button();
            this.pageSetupDialog1 = new System.Windows.Forms.PageSetupDialog();
            this.SuspendLayout();
            // 
            // lblpeso
            // 
            this.lblpeso.AutoSize = true;
            this.lblpeso.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblpeso.Location = new System.Drawing.Point(12, 19);
            this.lblpeso.Name = "lblpeso";
            this.lblpeso.Size = new System.Drawing.Size(39, 16);
            this.lblpeso.TabIndex = 0;
            this.lblpeso.Text = "Peso";
            // 
            // lblaltura
            // 
            this.lblaltura.AutoSize = true;
            this.lblaltura.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblaltura.Location = new System.Drawing.Point(12, 69);
            this.lblaltura.Name = "lblaltura";
            this.lblaltura.Size = new System.Drawing.Size(41, 16);
            this.lblaltura.TabIndex = 1;
            this.lblaltura.Text = "Altura";
            // 
            // mskbxpeso
            // 
            this.mskbxpeso.Location = new System.Drawing.Point(93, 14);
            this.mskbxpeso.Mask = "000.00";
            this.mskbxpeso.Name = "mskbxpeso";
            this.mskbxpeso.Size = new System.Drawing.Size(224, 20);
            this.mskbxpeso.TabIndex = 2;
            this.mskbxpeso.Validated += new System.EventHandler(this.mskbxpeso_Validated);
            // 
            // mskbxaltura
            // 
            this.mskbxaltura.Location = new System.Drawing.Point(93, 69);
            this.mskbxaltura.Mask = "0.00";
            this.mskbxaltura.Name = "mskbxaltura";
            this.mskbxaltura.Size = new System.Drawing.Size(224, 20);
            this.mskbxaltura.TabIndex = 3;
            this.mskbxaltura.Validated += new System.EventHandler(this.mskbxaltura_Validated);
            // 
            // bttcalcular
            // 
            this.bttcalcular.Location = new System.Drawing.Point(67, 213);
            this.bttcalcular.Name = "bttcalcular";
            this.bttcalcular.Size = new System.Drawing.Size(115, 53);
            this.bttcalcular.TabIndex = 4;
            this.bttcalcular.Text = "Calcular IMC";
            this.bttcalcular.UseVisualStyleBackColor = true;
            this.bttcalcular.Click += new System.EventHandler(this.bttcalcular_Click);
            // 
            // txtresult
            // 
            this.txtresult.Enabled = false;
            this.txtresult.Location = new System.Drawing.Point(93, 132);
            this.txtresult.Name = "txtresult";
            this.txtresult.Size = new System.Drawing.Size(224, 20);
            this.txtresult.TabIndex = 5;
            // 
            // lblimc
            // 
            this.lblimc.AutoSize = true;
            this.lblimc.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblimc.Location = new System.Drawing.Point(15, 132);
            this.lblimc.Name = "lblimc";
            this.lblimc.Size = new System.Drawing.Size(30, 16);
            this.lblimc.TabIndex = 6;
            this.lblimc.Text = "IMC";
            // 
            // lblclass
            // 
            this.lblclass.AutoSize = true;
            this.lblclass.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblclass.Location = new System.Drawing.Point(454, 19);
            this.lblclass.Name = "lblclass";
            this.lblclass.Size = new System.Drawing.Size(88, 16);
            this.lblclass.TabIndex = 7;
            this.lblclass.Text = "Classificação";
            // 
            // txtclass
            // 
            this.txtclass.Enabled = false;
            this.txtclass.Location = new System.Drawing.Point(438, 38);
            this.txtclass.Name = "txtclass";
            this.txtclass.Size = new System.Drawing.Size(116, 20);
            this.txtclass.TabIndex = 8;
            // 
            // bttlimpar
            // 
            this.bttlimpar.Location = new System.Drawing.Point(227, 213);
            this.bttlimpar.Name = "bttlimpar";
            this.bttlimpar.Size = new System.Drawing.Size(126, 53);
            this.bttlimpar.TabIndex = 9;
            this.bttlimpar.Text = "Limpar";
            this.bttlimpar.UseVisualStyleBackColor = true;
            this.bttlimpar.Click += new System.EventHandler(this.bttlimpar_Click);
            // 
            // bttsair
            // 
            this.bttsair.Location = new System.Drawing.Point(414, 213);
            this.bttsair.Name = "bttsair";
            this.bttsair.Size = new System.Drawing.Size(119, 53);
            this.bttsair.TabIndex = 10;
            this.bttsair.Text = "Sair";
            this.bttsair.UseVisualStyleBackColor = true;
            this.bttsair.Click += new System.EventHandler(this.bttsair_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(619, 317);
            this.Controls.Add(this.bttsair);
            this.Controls.Add(this.bttlimpar);
            this.Controls.Add(this.txtclass);
            this.Controls.Add(this.lblclass);
            this.Controls.Add(this.lblimc);
            this.Controls.Add(this.txtresult);
            this.Controls.Add(this.bttcalcular);
            this.Controls.Add(this.mskbxaltura);
            this.Controls.Add(this.mskbxpeso);
            this.Controls.Add(this.lblaltura);
            this.Controls.Add(this.lblpeso);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblpeso;
        private System.Windows.Forms.Label lblaltura;
        private System.Windows.Forms.MaskedTextBox mskbxpeso;
        private System.Windows.Forms.MaskedTextBox mskbxaltura;
        private System.Windows.Forms.Button bttcalcular;
        private System.Windows.Forms.TextBox txtresult;
        private System.Windows.Forms.Label lblimc;
        private System.Windows.Forms.Label lblclass;
        private System.Windows.Forms.TextBox txtclass;
        private System.Windows.Forms.Button bttlimpar;
        private System.Windows.Forms.Button bttsair;
        private System.Windows.Forms.PageSetupDialog pageSetupDialog1;
    }
}

