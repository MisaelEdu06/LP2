﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Psalario
{
    public partial class Form1 : Form
    {
        public double SalBruto;
        

        private void txtNomeFun_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (char.IsNumber(e.KeyChar) || char.IsPunctuation(e.KeyChar))
            {
                MessageBox.Show("Caracter Inválido!");
                SendKeys.Send("{BACKSPACE}");
            }
        }

        private void bttVerificar_Click(object sender, EventArgs e)
        {
            double SalLiq=0, NumFilhos=0, DescontoINSS=0, DescontoIRPF=0, BonusFilh=0;

            SalBruto = double.Parse(mskbxSalBrut.Text);
            NumFilhos = double.Parse(nupNumFilhos.Text);

            if (SalBruto < 800.47)
            {
                txtAliquotaINSS.Text = "7,65%";
                DescontoINSS = 0.0765 * SalBruto;
                txtDescINSS.Text = DescontoINSS.ToString();
            }
            else if (SalBruto <= 1050)
            {
                txtAliquotaINSS.Text = "8,65%";
                DescontoINSS = 0.0865 * SalBruto;
                txtDescINSS.Text = DescontoINSS.ToString();
            }
            else if (SalBruto <= 1400.77)
            {
                txtAliquotaINSS.Text = "9.00%";
                DescontoINSS = 0.09 * SalBruto;
                txtDescINSS.Text = DescontoINSS.ToString();
            }
            else if (SalBruto <= 2801.56)
            {
                txtAliquotaINSS.Text = "11.00%";
                DescontoINSS = 0.11 * SalBruto;
                txtDescINSS.Text = DescontoINSS.ToString();
            }
            else
            {
                txtAliquotaINSS.Text = "Teto";
                DescontoINSS = 308.17;
                txtDescINSS.Text = DescontoINSS.ToString();
            }




            if (SalBruto < 1257.12)
            {
                txtAliquotaIRPF.Text = "Insento";
                txtDescIRPF.Text = "Insento";
            }

            else if (SalBruto <= 2512.08)
            {
                txtAliquotaIRPF.Text = "15.00%";
                DescontoIRPF = 0.15 * SalBruto;
                txtDescIRPF.Text = DescontoIRPF.ToString();
            }
            else
            {
                txtAliquotaIRPF.Text = "27.5%";
                DescontoIRPF = 0.275 * SalBruto;
                txtDescIRPF.Text = DescontoIRPF.ToString();
            }


            if (SalBruto <= 435)
            {
                BonusFilh = NumFilhos * 22.33;
                txtSalFami.Text = BonusFilh.ToString();
            }
            else if (SalBruto <= 654.61)
            {
                BonusFilh = NumFilhos * 15.74;
                txtSalFami.Text = BonusFilh.ToString();
            }
            else txtSalFami.Text = "-";


            txtSalFami.Text = BonusFilh.ToString();

            SalLiq = SalBruto - DescontoIRPF - DescontoINSS + BonusFilh;
            txtSalLiq.Text = SalLiq.ToString();

            
        }

        public string NomeFun;
        public Form1()
        {
            InitializeComponent();
        }

       
    }
}
