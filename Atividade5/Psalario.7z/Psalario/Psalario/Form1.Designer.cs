﻿namespace Psalario
{
    partial class Form1
    {
        /// <summary>
        /// Variável de designer necessária.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpar os recursos que estão sendo usados.
        /// </summary>
        /// <param name="disposing">true se for necessário descartar os recursos gerenciados; caso contrário, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código gerado pelo Windows Form Designer

        /// <summary>
        /// Método necessário para suporte ao Designer - não modifique 
        /// o conteúdo deste método com o editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblNome = new System.Windows.Forms.Label();
            this.mskbxSalBrut = new System.Windows.Forms.MaskedTextBox();
            this.nupNumFilhos = new System.Windows.Forms.NumericUpDown();
            this.txtNomeFun = new System.Windows.Forms.TextBox();
            this.lblSalBruto = new System.Windows.Forms.Label();
            this.lblnumfilhos = new System.Windows.Forms.Label();
            this.bttVerificar = new System.Windows.Forms.Button();
            this.lblAliquotaINSS = new System.Windows.Forms.Label();
            this.lblAliquotaIRPRF = new System.Windows.Forms.Label();
            this.lblSalFami = new System.Windows.Forms.Label();
            this.lblSalLiq = new System.Windows.Forms.Label();
            this.lblDescIRPF = new System.Windows.Forms.Label();
            this.lblDescINSS = new System.Windows.Forms.Label();
            this.txtAliquotaINSS = new System.Windows.Forms.TextBox();
            this.txtAliquotaIRPF = new System.Windows.Forms.TextBox();
            this.txtSalFami = new System.Windows.Forms.TextBox();
            this.txtSalLiq = new System.Windows.Forms.TextBox();
            this.txtDescINSS = new System.Windows.Forms.TextBox();
            this.txtDescIRPF = new System.Windows.Forms.TextBox();
            ((System.ComponentModel.ISupportInitialize)(this.nupNumFilhos)).BeginInit();
            this.SuspendLayout();
            // 
            // lblNome
            // 
            this.lblNome.AutoSize = true;
            this.lblNome.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblNome.Location = new System.Drawing.Point(28, 30);
            this.lblNome.Name = "lblNome";
            this.lblNome.Size = new System.Drawing.Size(131, 18);
            this.lblNome.TabIndex = 0;
            this.lblNome.Text = "Nome Funcionário";
            // 
            // mskbxSalBrut
            // 
            this.mskbxSalBrut.Location = new System.Drawing.Point(165, 71);
            this.mskbxSalBrut.Mask = "00000.00";
            this.mskbxSalBrut.Name = "mskbxSalBrut";
            this.mskbxSalBrut.Size = new System.Drawing.Size(112, 20);
            this.mskbxSalBrut.TabIndex = 1;
            // 
            // nupNumFilhos
            // 
            this.nupNumFilhos.Location = new System.Drawing.Point(165, 126);
            this.nupNumFilhos.Maximum = new decimal(new int[] {
            20,
            0,
            0,
            0});
            this.nupNumFilhos.Name = "nupNumFilhos";
            this.nupNumFilhos.Size = new System.Drawing.Size(84, 20);
            this.nupNumFilhos.TabIndex = 2;
            // 
            // txtNomeFun
            // 
            this.txtNomeFun.Location = new System.Drawing.Point(165, 28);
            this.txtNomeFun.Name = "txtNomeFun";
            this.txtNomeFun.Size = new System.Drawing.Size(388, 20);
            this.txtNomeFun.TabIndex = 3;
            this.txtNomeFun.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtNomeFun_KeyPress);
            // 
            // lblSalBruto
            // 
            this.lblSalBruto.AutoSize = true;
            this.lblSalBruto.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblSalBruto.Location = new System.Drawing.Point(28, 70);
            this.lblSalBruto.Name = "lblSalBruto";
            this.lblSalBruto.Size = new System.Drawing.Size(94, 18);
            this.lblSalBruto.TabIndex = 4;
            this.lblSalBruto.Text = "Salário Bruto";
            // 
            // lblnumfilhos
            // 
            this.lblnumfilhos.AutoSize = true;
            this.lblnumfilhos.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblnumfilhos.Location = new System.Drawing.Point(28, 124);
            this.lblnumfilhos.Name = "lblnumfilhos";
            this.lblnumfilhos.Size = new System.Drawing.Size(126, 18);
            this.lblnumfilhos.TabIndex = 5;
            this.lblnumfilhos.Text = "Número de Filhos";
            // 
            // bttVerificar
            // 
            this.bttVerificar.Location = new System.Drawing.Point(165, 187);
            this.bttVerificar.Name = "bttVerificar";
            this.bttVerificar.Size = new System.Drawing.Size(230, 37);
            this.bttVerificar.TabIndex = 6;
            this.bttVerificar.Text = "Verificar Desconto";
            this.bttVerificar.UseVisualStyleBackColor = true;
            this.bttVerificar.Click += new System.EventHandler(this.bttVerificar_Click);
            // 
            // lblAliquotaINSS
            // 
            this.lblAliquotaINSS.AutoSize = true;
            this.lblAliquotaINSS.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblAliquotaINSS.Location = new System.Drawing.Point(28, 269);
            this.lblAliquotaINSS.Name = "lblAliquotaINSS";
            this.lblAliquotaINSS.Size = new System.Drawing.Size(98, 18);
            this.lblAliquotaINSS.TabIndex = 7;
            this.lblAliquotaINSS.Text = "Aliquota INSS";
            // 
            // lblAliquotaIRPRF
            // 
            this.lblAliquotaIRPRF.AutoSize = true;
            this.lblAliquotaIRPRF.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblAliquotaIRPRF.Location = new System.Drawing.Point(28, 307);
            this.lblAliquotaIRPRF.Name = "lblAliquotaIRPRF";
            this.lblAliquotaIRPRF.Size = new System.Drawing.Size(97, 18);
            this.lblAliquotaIRPRF.TabIndex = 8;
            this.lblAliquotaIRPRF.Text = "Aliquota IRPF";
            // 
            // lblSalFami
            // 
            this.lblSalFami.AutoSize = true;
            this.lblSalFami.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblSalFami.Location = new System.Drawing.Point(28, 349);
            this.lblSalFami.Name = "lblSalFami";
            this.lblSalFami.Size = new System.Drawing.Size(105, 18);
            this.lblSalFami.TabIndex = 9;
            this.lblSalFami.Text = "Salário Família";
            // 
            // lblSalLiq
            // 
            this.lblSalLiq.AutoSize = true;
            this.lblSalLiq.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblSalLiq.Location = new System.Drawing.Point(28, 392);
            this.lblSalLiq.Name = "lblSalLiq";
            this.lblSalLiq.Size = new System.Drawing.Size(105, 18);
            this.lblSalLiq.TabIndex = 10;
            this.lblSalLiq.Text = "Salário Liquido";
            // 
            // lblDescIRPF
            // 
            this.lblDescIRPF.AutoSize = true;
            this.lblDescIRPF.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblDescIRPF.Location = new System.Drawing.Point(458, 307);
            this.lblDescIRPF.Name = "lblDescIRPF";
            this.lblDescIRPF.Size = new System.Drawing.Size(110, 18);
            this.lblDescIRPF.TabIndex = 11;
            this.lblDescIRPF.Text = "Desconto IRPF";
            // 
            // lblDescINSS
            // 
            this.lblDescINSS.AutoSize = true;
            this.lblDescINSS.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblDescINSS.Location = new System.Drawing.Point(458, 269);
            this.lblDescINSS.Name = "lblDescINSS";
            this.lblDescINSS.Size = new System.Drawing.Size(111, 18);
            this.lblDescINSS.TabIndex = 12;
            this.lblDescINSS.Text = "Desconto INSS";
            // 
            // txtAliquotaINSS
            // 
            this.txtAliquotaINSS.Enabled = false;
            this.txtAliquotaINSS.Location = new System.Drawing.Point(165, 270);
            this.txtAliquotaINSS.Name = "txtAliquotaINSS";
            this.txtAliquotaINSS.Size = new System.Drawing.Size(145, 20);
            this.txtAliquotaINSS.TabIndex = 13;
            // 
            // txtAliquotaIRPF
            // 
            this.txtAliquotaIRPF.Enabled = false;
            this.txtAliquotaIRPF.Location = new System.Drawing.Point(165, 308);
            this.txtAliquotaIRPF.Name = "txtAliquotaIRPF";
            this.txtAliquotaIRPF.Size = new System.Drawing.Size(145, 20);
            this.txtAliquotaIRPF.TabIndex = 14;
            // 
            // txtSalFami
            // 
            this.txtSalFami.Enabled = false;
            this.txtSalFami.Location = new System.Drawing.Point(165, 347);
            this.txtSalFami.Name = "txtSalFami";
            this.txtSalFami.Size = new System.Drawing.Size(145, 20);
            this.txtSalFami.TabIndex = 15;
            // 
            // txtSalLiq
            // 
            this.txtSalLiq.Enabled = false;
            this.txtSalLiq.Location = new System.Drawing.Point(165, 390);
            this.txtSalLiq.Name = "txtSalLiq";
            this.txtSalLiq.Size = new System.Drawing.Size(145, 20);
            this.txtSalLiq.TabIndex = 16;
            // 
            // txtDescINSS
            // 
            this.txtDescINSS.Enabled = false;
            this.txtDescINSS.Location = new System.Drawing.Point(575, 270);
            this.txtDescINSS.Name = "txtDescINSS";
            this.txtDescINSS.Size = new System.Drawing.Size(145, 20);
            this.txtDescINSS.TabIndex = 17;
            // 
            // txtDescIRPF
            // 
            this.txtDescIRPF.Enabled = false;
            this.txtDescIRPF.Location = new System.Drawing.Point(574, 308);
            this.txtDescIRPF.Name = "txtDescIRPF";
            this.txtDescIRPF.Size = new System.Drawing.Size(145, 20);
            this.txtDescIRPF.TabIndex = 18;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.txtDescIRPF);
            this.Controls.Add(this.txtDescINSS);
            this.Controls.Add(this.txtSalLiq);
            this.Controls.Add(this.txtSalFami);
            this.Controls.Add(this.txtAliquotaIRPF);
            this.Controls.Add(this.txtAliquotaINSS);
            this.Controls.Add(this.lblDescINSS);
            this.Controls.Add(this.lblDescIRPF);
            this.Controls.Add(this.lblSalLiq);
            this.Controls.Add(this.lblSalFami);
            this.Controls.Add(this.lblAliquotaIRPRF);
            this.Controls.Add(this.lblAliquotaINSS);
            this.Controls.Add(this.bttVerificar);
            this.Controls.Add(this.lblnumfilhos);
            this.Controls.Add(this.lblSalBruto);
            this.Controls.Add(this.txtNomeFun);
            this.Controls.Add(this.nupNumFilhos);
            this.Controls.Add(this.mskbxSalBrut);
            this.Controls.Add(this.lblNome);
            this.Name = "Form1";
            this.Text = "Form1";
            ((System.ComponentModel.ISupportInitialize)(this.nupNumFilhos)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblNome;
        private System.Windows.Forms.MaskedTextBox mskbxSalBrut;
        private System.Windows.Forms.NumericUpDown nupNumFilhos;
        private System.Windows.Forms.TextBox txtNomeFun;
        private System.Windows.Forms.Label lblSalBruto;
        private System.Windows.Forms.Label lblnumfilhos;
        private System.Windows.Forms.Button bttVerificar;
        private System.Windows.Forms.Label lblAliquotaINSS;
        private System.Windows.Forms.Label lblAliquotaIRPRF;
        private System.Windows.Forms.Label lblSalFami;
        private System.Windows.Forms.Label lblSalLiq;
        private System.Windows.Forms.Label lblDescIRPF;
        private System.Windows.Forms.Label lblDescINSS;
        private System.Windows.Forms.TextBox txtAliquotaINSS;
        private System.Windows.Forms.TextBox txtAliquotaIRPF;
        private System.Windows.Forms.TextBox txtSalFami;
        private System.Windows.Forms.TextBox txtSalLiq;
        private System.Windows.Forms.TextBox txtDescINSS;
        private System.Windows.Forms.TextBox txtDescIRPF;
    }
}

